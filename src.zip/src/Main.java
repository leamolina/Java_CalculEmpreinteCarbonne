import consoCarbonne.Logement  ;
import consoCarbonne.CE ;
import consoCarbonne.Alimentation ;
import consoCarbonne.ConsoCarbonne;
import consoCarbonne.BienConso;
import consoCarbonne.Transport;
import consoCarbonne.Taille;

public class Main {
    public static void main(String[] args) {

        //Tests sur Logement
        Logement l = new Logement(128, CE.A);
        System.out.println(l.toString());
        Logement.EmpreinteLogement();

        //Tests sur Alimentation
        Alimentation a = new Alimentation(0.5, 0.2);
        System.out.println(a.toString());
        Alimentation.EmpreinteAlimentation();


        //Tests sur consoCarbonne
        ConsoCarbonne c = new ConsoCarbonne();
        System.out.println(c.toString());


        //Tests sur bienConso
        BienConso b = new BienConso(1750);
        System.out.println(b.toString());
        BienConso.EmpreinteBienConso();

        //Tests sur Transport:
        Transport t = new Transport(Taille.P, true, 5, 16 );
        System.out.println(t.toString());
        Transport.EmpreinteTransport();




    }


}
