package consoCarbonne;

public enum Taille {P,G}

