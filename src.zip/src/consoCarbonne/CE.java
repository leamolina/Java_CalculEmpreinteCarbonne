package consoCarbonne;

public enum CE {A, B, C, D, E, F, G}

